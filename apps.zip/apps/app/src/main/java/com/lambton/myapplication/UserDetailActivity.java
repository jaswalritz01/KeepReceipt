package com.lambton.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.lambton.myapplication.db.DBManager;
import com.lambton.myapplication.model.User;

import java.util.ArrayList;

public class UserDetailActivity extends ImagePickActivity implements View.OnClickListener {

    ImageView imvUserImage;
    EditText etFName;
    EditText etLName;
    EditText etAccountNumber;
    User mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        imvUserImage = findViewById(R.id.imvUserImage);
        etAccountNumber = findViewById(R.id.etAccountNumber);
        etLName = findViewById(R.id.etLName);
        etFName = findViewById(R.id.etFName);

        findViewById(R.id.btnSave).setOnClickListener(this);
        imvUserImage.setOnClickListener(this);

        ArrayList<User> users = DBManager.getInstance().dbHelper.getAllUsersRecords();

        if (users.size() > 0)
            updateDetail(users.get(0));

    }

    private void updateDetail(User user) {
        mUser = user;

        etAccountNumber.setText(user.accountNumber);
        etLName.setText(user.firstName);
        etFName.setText(user.lastName);

        if (mUser.photoPath != null && !mUser.photoPath.isEmpty()) {
            Bitmap bitmap = BitmapFactory.decodeFile(mUser.photoPath);
            imvUserImage.setImageBitmap(bitmap);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imvUserImage:
                selectImage(true);
                break;

            case R.id.btnSave:
                if (validate())
                    saveInDB();
                else
                    Toast.makeText(this, R.string.fill_all_details, Toast.LENGTH_SHORT).show();
                break;

        }
    }

    private void saveInDB() {
        String fName = etFName.getText().toString();
        String accountNumber = etAccountNumber.getText().toString();
        String lName = etLName.getText().toString();

        if (mUser == null)
            mUser = new User();

        mUser.accountNumber = accountNumber;
        mUser.firstName = lName;
        mUser.lastName = fName;

        if (imagePath != null)
            mUser.photoPath = imagePath;

        if (DBManager.getInstance().dbHelper.updateUserDetail(mUser) > 0) {
            Toast.makeText(this, "Your details has been updated :)", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.failed_to_save, Toast.LENGTH_SHORT).show();
        }

        onBackPressed();
    }

    private boolean validate() {
        String fName = etFName.getText().toString();
        String accountNumber = etAccountNumber.getText().toString();
        String lName = etLName.getText().toString();

        return !fName.isEmpty() && !accountNumber.isEmpty() && !lName.isEmpty();
    }


    @Override
    protected void setImageBitmap(Bitmap thumbnail, String path) {
        imvUserImage.setImageBitmap(thumbnail);
        imagePath = path;
    }
}
