package com.lambton.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.lambton.myapplication.db.DBManager;
import com.lambton.myapplication.model.Receipt;

import java.util.ArrayList;

public class ViewReceiptActivity extends AppCompatActivity {

    ListView lvRecords;
    ArrayList<Receipt> arrayList = new ArrayList<>();
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_receipt);

        lvRecords = findViewById(R.id.lvRecords);

        arrayList = DBManager.getInstance().dbHelper.getAllReceipts();

        findViewById(R.id.btnCreateRC).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCR();
            }
        });

        reload();
        setTitle("View Receipts");

        /*if (arrayList.size() > 0) {
            customAdapter = new CustomAdapter(this);
            lvRecords.setAdapter(customAdapter);
        } else {
            Toast.makeText(this, "There is no records found!", Toast.LENGTH_SHORT).show();
        }*/
    }

    private void openCR() {
        int idGroup = -1;

        //get from back view
        if (getIntent().hasExtra("id")) {
            idGroup = getIntent().getIntExtra("id", -1);
        }

        Intent intent = new Intent(this, CreateReceiptActivity.class);
        intent.putExtra("id", idGroup);

        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        if (lvRecords == null)
            return;

        String idGroup = null;

        //get from back view
        if (getIntent().hasExtra("id")) {
            idGroup = getIntent().getStringExtra("id");
        }

        if (idGroup == null)
            arrayList = DBManager.getInstance().dbHelper.getAllReceipts();
        else
            arrayList = DBManager.getInstance().dbHelper.getReceiptsWithGroup(idGroup);

        customAdapter = new CustomAdapter(this);
        lvRecords.setAdapter(customAdapter);

        /*lvRecords.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openReceiptView(position);
            }
        });*/
        if (arrayList.size() > 0) {
        } else {
            Toast.makeText(this, "There is no records found!", Toast.LENGTH_SHORT).show();
        }
    }

    private void openReceiptView(int position) {

        CreateReceiptActivity.receiptForEditMode = arrayList.get(position);

        Intent intent = new Intent(this, CreateReceiptActivity.class);
        intent.putExtra("editMode", "editMode");

        startActivity(intent);

    }

    private class CustomAdapter implements ListAdapter {
        Context context;

        public CustomAdapter(Context context) {
            this.context = context;
        }

        @Override
        public void registerDataSetObserver(DataSetObserver observer) {

        }

        @Override
        public void unregisterDataSetObserver(DataSetObserver observer) {

        }

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }


        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            Receipt subjectData = arrayList.get(position);
            if (convertView == null) {
                LayoutInflater layoutInflater = LayoutInflater.from(context);
                convertView = layoutInflater.inflate(R.layout.list_row, null);

                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openReceiptView(position);
                    }
                });

                TextView tvName = convertView.findViewById(R.id.tvName);
                Button btnDelete = convertView.findViewById(R.id.btnDelete);
                btnDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        deleteItem(position);
                    }
                });

                tvName.setText(subjectData.name);

            }
            return convertView;
        }

        private void deleteItem(final int position) {
            AlertDialog alertDialog = new AlertDialog.Builder(ViewReceiptActivity.this).create();
            alertDialog.setTitle("Alert");
            alertDialog.setMessage("Are you sure want to remove?");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "YES",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            removeItemAt(position);

                        }
                    });
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "NO",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();


        }

        void removeItemAt(int position) {
            DBManager.getInstance().dbHelper.removeReceipt(arrayList.get(position));
            reload();
        }

        @Override
        public int getItemViewType(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return false;
        }
    }
}
