package com.lambton.myapplication.db;



import com.lambton.myapplication.AppController;

public class DBManager {
    private static DBManager ourInstance = new DBManager();
    public DBHelper dbHelper;

    private DBManager() {
        dbHelper = new DBHelper(AppController.getInstance());
    }

    public static DBManager getInstance() {
        return ourInstance;
    }

//    public ArrayList<ContentModel> podCastMainArray = new ArrayList<>();

}
