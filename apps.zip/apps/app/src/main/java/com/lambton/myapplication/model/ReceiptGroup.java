package com.lambton.myapplication.model;

import android.database.Cursor;

import com.lambton.myapplication.db.DBHelper;

public class ReceiptGroup {
    public String name;
    public String id;

    public ReceiptGroup(Cursor cursor) {
        id = DBHelper.getValueForColumn(cursor, DBHelper.GroupTable.COLUMN_ID);
        name = DBHelper.getValueForColumn(cursor, DBHelper.GroupTable.COLUMN_NAME);
    }

}

