package com.lambton.myapplication.model;

import android.database.Cursor;

import com.lambton.myapplication.db.DBHelper;

public class User {

    public String firstName = "";
    public String id = "";
    public String lastName = "";
    public String accountNumber = "";
    public String photoPath = "";

    public User(Cursor cursor) {
        photoPath = DBHelper.getValueForColumn(cursor, DBHelper.UserTable.COLUMN_PHOTO_PATH);
        accountNumber = DBHelper.getValueForColumn(cursor, DBHelper.UserTable.COLUMN_ACCOUNT_NUMBER);
        lastName = DBHelper.getValueForColumn(cursor, DBHelper.UserTable.COLUMN_LAST_NAME);
        id = DBHelper.getValueForColumn(cursor, DBHelper.UserTable.COLUMN_ID);
        firstName = DBHelper.getValueForColumn(cursor, DBHelper.UserTable.COLUMN_FIRST_NAME);
    }

    public User() {

    }
}
