package com.lambton.myapplication.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.lambton.myapplication.model.Receipt;
import com.lambton.myapplication.model.ReceiptGroup;
import com.lambton.myapplication.model.User;

import java.util.ArrayList;


public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ReceiptDB_v1_2.db";


    public interface UserTable {
        String TABLE_NAME = "users";
        String COLUMN_ID = "id";
        String COLUMN_FIRST_NAME = "first_name";
        String COLUMN_LAST_NAME = "last_name";
        String COLUMN_PHOTO_PATH = "photo_path";
        String COLUMN_ACCOUNT_NUMBER = "account_number";
    }

    public interface GroupTable {
        String TABLE_NAME = "groups";
        String COLUMN_ID = "id";
        String COLUMN_NAME = "group_name";
    }

    public interface ReceiptTable {
        String TABLE_NAME = "receipt";
        String COLUMN_ID = "id";
        String COLUMN_NAME = "name";
        String COLUMN_GROUP_ID = "group_id";
        String COLUMN_DESCRIPTION = "description";
        String COLUMN_DATE = "date";
        String COLUMN_SNAPSHOP_PATH = "snapshot";
        String COLUMN_AMOUNT = "amount";
    }

    public static final long DATABASE_FAILED_TO_SAVE = -1;
    //private UserManager userManager = UserManager.getInstance();

    //private HashMap hp;

    DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    /**
     * Common code for helping in database
     */
    public static String getValueForColumn(Cursor res, String key) {
        return res.getString(res.getColumnIndex(key));
    }

    //DataBase creation
    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryToCreateTable = "create table " + UserTable.TABLE_NAME;
        String append = "(" + UserTable.COLUMN_ID + " integer primary key," +
                UserTable.COLUMN_FIRST_NAME + " text," +
                UserTable.COLUMN_LAST_NAME + " text," +
                UserTable.COLUMN_PHOTO_PATH + " text," +
                UserTable.COLUMN_ACCOUNT_NUMBER + " text )";

        String queryToCreateTableGroup = "create table " + GroupTable.TABLE_NAME;
        String appendgroup = "(" + GroupTable.COLUMN_ID + " integer primary key," +
                GroupTable.COLUMN_NAME + " text)";

        db.execSQL(
                queryToCreateTable + append
        );

        db.execSQL(
                queryToCreateTableGroup + appendgroup
        );

        String queryToCreateTableRecept = "create table " + ReceiptTable.TABLE_NAME;
        String appendRecept = "(" + ReceiptTable.COLUMN_ID + " integer primary key," +
                ReceiptTable.COLUMN_NAME + " text," +
                ReceiptTable.COLUMN_GROUP_ID + " text," +
                ReceiptTable.COLUMN_DESCRIPTION + " text," +
                ReceiptTable.COLUMN_DATE + " text," +
                ReceiptTable.COLUMN_SNAPSHOP_PATH + " text," +
                ReceiptTable.COLUMN_AMOUNT + " text )";

        db.execSQL(
                queryToCreateTableRecept + appendRecept
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + GroupTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + ReceiptTable.TABLE_NAME);
        onCreate(db);
    }

    /**
     * Methods to fetch data from database
     * Different methods used for get the data by different conditions
     */

    public ArrayList<User> getAllUsersRecords() {
        return getDataBaseRecordsAt(null, null);
    }

    public long updateUserDetail(User user) {
        if (isUserExist(user)) {
            //Update
            return updateUserData(user);
        } else
            return insertWithDBModel(user);
    }

    public long addGroup(String groupName) {
        return insertGroup(groupName);
    }


    public ArrayList<ReceiptGroup> getAllGroups() {
        ArrayList<ReceiptGroup> arrayList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String table = GroupTable.TABLE_NAME;
        String[] columns = {"*"};

        Cursor cursor = db.query(table, columns, null, null, null, null, null);
        cursor.moveToFirst();


        while (!cursor.isAfterLast()) {
            ReceiptGroup model = new ReceiptGroup(cursor);
            arrayList.add(model);
            cursor.moveToNext();
        }
        cursor.close();
        return arrayList;
    }


    private ArrayList<User> getDataBaseRecordsAt(String where, String[] args) {
        ArrayList<User> arrayList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String table = UserTable.TABLE_NAME;
        String[] columns = {"*"};

        Cursor cursor = db.query(table, columns, where, args, null, null, null);
        cursor.moveToFirst();


        while (!cursor.isAfterLast()) {
            User model = new User(cursor);
            arrayList.add(model);
            cursor.moveToNext();
        }
        cursor.close();
        return arrayList;
    }


    /**
     * delete the data operations
     */
    /*public void clearAllRecords() {
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(RECORDS_TABLE_NAME, null, null);
        db.close();
    }

    public Integer deleteItemById(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(RECORDS_TABLE_NAME,
                RECORDS_COLUMN_ID + "= ? ",
                new String[]{Integer.toString(id)});
    }*/
    public int removeReceipt(Receipt receipt) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(ReceiptTable.TABLE_NAME,
                ReceiptTable.COLUMN_ID + "= ? ",
                new String[]{receipt.id});
    }

    //Remove Group
    public int removeGroup(ReceiptGroup receiptGroup) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(GroupTable.TABLE_NAME,
                GroupTable.COLUMN_ID + "= ? ",
                new String[]{receiptGroup.id});
    }


    /**
     * saveData insert operations
     */
    private long insertWithDBModel(User dbModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(UserTable.COLUMN_FIRST_NAME, dbModel.firstName);
        contentValues.put(UserTable.COLUMN_LAST_NAME, dbModel.lastName);
        contentValues.put(UserTable.COLUMN_ACCOUNT_NUMBER, dbModel.accountNumber);
        contentValues.put(UserTable.COLUMN_PHOTO_PATH, dbModel.photoPath);

        long id = db.insert(UserTable.TABLE_NAME, null, contentValues);

        return id;
    }


    private boolean isUserExist(User user) {
        return getAllUsersRecords().size() > 0;
    }



    /*public String isNameExist(String fileName) {

        SQLiteDatabase db = this.getReadableDatabase();

        String contentTypeQuery = " AND ( " + RECORDS_COLUMN_TYPE + " = '" + ContentType.Recording
                .toString() + "' OR " + RECORDS_COLUMN_TYPE + " = '" + ContentType.Ringtone
                .toString() + "' )";

        String Query = "select * from " + RECORDS_TABLE_NAME + " where (" + RECORDS_COLUMN_NAME +
                " = '" + fileName + "' )" + contentTypeQuery;

        Cursor cursor = db.rawQuery(Query, null);

        if (cursor == null) {
            return null;
        }

        if (cursor.getCount() <= 0) {
            cursor.close();
            return null;
        }

        cursor.moveToFirst();
        ContentModel cursorModel = null;
        while (!cursor.isAfterLast()) {
            cursorModel = new ContentModel(cursor);
            cursor.moveToNext();
        }

        if (cursorModel == null)
            return null;

        cursor.close();
        //send true in case of
        return cursorModel.contentBasicInfo.getIDNotNull();
    }*/

    //No used for now
    private long updateUserData(User user) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(UserTable.COLUMN_FIRST_NAME, user.firstName);
        contentValues.put(UserTable.COLUMN_LAST_NAME, user.lastName);
        contentValues.put(UserTable.COLUMN_ACCOUNT_NUMBER, user.accountNumber);
        contentValues.put(UserTable.COLUMN_PHOTO_PATH, user.photoPath);

        String where = UserTable.COLUMN_ID + "=? ";
        String[] args = {user.id};

        long id = db.update(UserTable.TABLE_NAME, contentValues, where, args);

        return id;
    }


    /// *** ----------------------------------------------------------------
    private long insertGroup(String groupName) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(GroupTable.COLUMN_NAME, groupName);

        long id = db.insert(GroupTable.TABLE_NAME, null, contentValues);

        return id;
    }

    public static final String ALL_GROUP_ID = "0";

    public long addReceipt(Receipt receipt) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(ReceiptTable.COLUMN_NAME, receipt.name);
        contentValues.put(ReceiptTable.COLUMN_DESCRIPTION, receipt.description);
        contentValues.put(ReceiptTable.COLUMN_DATE, receipt.date);
        contentValues.put(ReceiptTable.COLUMN_AMOUNT, receipt.amount);
        contentValues.put(ReceiptTable.COLUMN_SNAPSHOP_PATH, receipt.snapshotPath);
        contentValues.put(ReceiptTable.COLUMN_GROUP_ID, receipt.groupID);

        long id = db.insert(ReceiptTable.TABLE_NAME, null, contentValues);

        return id;
    }

    public ArrayList<Receipt> getAllReceipts() {
        ArrayList<Receipt> arrayList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String table = ReceiptTable.TABLE_NAME;
        String[] columns = {"*"};

        Cursor cursor = db.query(table, columns, null, null, null,
                null, null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()) {
            Receipt model = new Receipt(cursor);
            arrayList.add(model);
            cursor.moveToNext();
        }
        cursor.close();
        return arrayList;
    }

    public ArrayList<Receipt> getReceiptsWithGroup(String idGroup) {
        ArrayList<Receipt> arrayList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String table = ReceiptTable.TABLE_NAME;
        String[] columns = {"*"};

        String where = ReceiptTable.COLUMN_GROUP_ID + "=? ";
        String[] args = {idGroup};

        Cursor cursor = db.query(table, columns, where, args, null,
                null, null);
        cursor.moveToFirst();

        while (!cursor.isAfterLast()) {
            Receipt model = new Receipt(cursor);
            arrayList.add(model);
            cursor.moveToNext();
        }
        cursor.close();
        return arrayList;
    }

}


