package com.lambton.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.lambton.myapplication.db.DBManager;

public class AddGroupReceiptActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etGroupName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_group_receipt);

        etGroupName = findViewById(R.id.etGroupName);
        findViewById(R.id.btnSave).setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (etGroupName.getText().toString().isEmpty()) {
            Toast.makeText(this, R.string.fill_all_details, Toast.LENGTH_SHORT).show();
        } else {
            if (DBManager.getInstance().dbHelper.addGroup(etGroupName.getText().toString()) > 0) {
                Toast.makeText(this, "Group Added successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, R.string.failed_to_save, Toast.LENGTH_SHORT).show();
            }
            onBackPressed();
        }
    }
}
